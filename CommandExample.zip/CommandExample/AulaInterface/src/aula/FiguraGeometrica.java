package aula;

public interface FiguraGeometrica {
    public int getArea();
    public String getNome();
    public int getPerimetro();
}
